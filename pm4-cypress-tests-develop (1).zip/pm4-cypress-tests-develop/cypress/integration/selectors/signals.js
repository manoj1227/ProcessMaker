export default {
    addSignalButton: "//button[normalize-space()='Signal']",
    nameSignal: "//input[@id='name']",
    idSignal: "//input[@id='id']",
    saveSignalButton: "//button[normalize-space()='Save']"
} 