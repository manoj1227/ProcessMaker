import selectors from "../selectors/tasks"
export class Tasks {

    clickOnToDoButton(){
        cy.xpath(selectors.tasksTable).should('be.visible');
        cy.get(selectors.sidebarCompletedButton).eq(0).click();
    }

    clickOnCompletedButton(){
        cy.xpath(selectors.tasksTable).should('be.visible');
        cy.get(selectors.sidebarCompletedButton).eq(1).click();
    }

    searchByPMQL(query){
    //Click in Field to write Query
        cy.xpath(selectors.tasksTable).should('be.visible');
        cy.get(selectors.searchbar).eq(0).type(query).should('have.value', query);
     //Click in Search Button
        cy.get(selectors.searchButton).eq(0).click();
        
    }
   

    verifyValueInTable(taskName){
        cy.xpath(selectors.tasksTable).should('be.visible');
        cy.xpath(selectors.tasksTable).should('be.visible').should('contain',taskName);
        
    }
    deleteQuery(){
        cy.get(selectors.searchbar).eq(0).clear();
        
    }

    searchTaskName(name){
        cy.get(selectors.searchbar).eq(0).type(name).click();
        cy.get(selectors.searchButton).eq(0).click();
        cy.get(selectors.openTaskButton).eq(0).click();
    }

    openSelfServiceTask(){
        cy.get(selectors.claimTaskSelfService).should('be.visible');
        cy.get(selectors.claimTaskSelfService).click();
        cy.get(selectors.claimTaskSelfService).should('not.exist');
    }

    verifyTitlePage (title) {
        cy.visit('/tasks');
        cy.title().should('eq', title);
    }

    verifySidebarMenuOption(num,option){
        cy.get('.nav-item.filter-bar.justify-content-between.py-2.sidebar-expansion').click();
        cy.get('.nav-item.filter-bar.justify-content-between').eq(num).should('contain',option);
    }
   
}
    