import selectors from "../selectors/requests"
import promisify from 'cypress-promise';
import { NavigationHelper } from "../helpers/navigationHelper";

let navHelper = new NavigationHelper();
export class Requests {
    clickOnTaskName(rowIndex, coloumnIndex) {
        cy.xpath((selectors.tasksTableCell.replace('rowIndex', rowIndex).replace('coloumnIndex', coloumnIndex)) + '//a').should('be.visible').click({ force: true });
    }

    async waitUntilTheRequestIsCompleted(timeOut) {
        var status;
        for (var i = 0; i < timeOut / 5; i++) {
            const text = await promisify(cy
                .get('h4')
                .then(el => el.text())
            )
            cy.log(text);
            if (text == 'Completed') {
                return true;
            }
            cy.wait(5000);
            cy.reload();
        }
        return false;
    }


    processIsInprogress(requestId) {
        cy.visit('/requests/' + requestId);
        cy.xpath("//h4[text()='In Progress']").should('be.visible');
    }

    openRequestById(requestId) {
        cy.wait(2000);
        cy.visit('/requests/' + requestId);
        cy.xpath("(//*[@class='vuetable-slot'])[1]").should('be.visible');
    }

    openRequestByName(processName) {
        navHelper.navigateToInprogressRequests();
        this.addRequestNameToSelectList(processName);
        cy.xpath(selectors.requestInputOption.replace('processName', processName)).click();
        cy.xpath("(//*[@class='vuetable-slot'])[1]").should('be.visible');
        this.getRequestID();
    }

    addRequestNameToSelectList(processName) {
        cy.xpath(selectors.requestDropDown).click();
        cy.wait(2000);
        cy.xpath(selectors.requestInput).type(processName).should('have.value', processName);
        cy.xpath(selectors.requestDropDownOption.replace('processName', processName)).click({ multiple: true });
        cy.xpath(selectors.requestSearchBox).click();
        cy.xpath(selectors.requestName.replace('processName', processName)).should('be.visible');
        // cy.xpath(selectors.screenForInputDropdown).should('have.value', screenName);
    }

    async getRequestID() {
        const requestId = await promisify(cy.url().then(url => {
            return url.split('/')[4].trim();
        }))
        return requestId;
    }


    verifyTaskIsCompleted() {
        cy.xpath(selectors.taskAlertTxt).should('be.visible');
    }

    clickOnSubmitButton() {
        cy.get(selectors.submitBtn).click({ force: true });
    }

    openTask(taskName) {
        cy.xpath(selectors.taskValueTxt.replace('taskName', taskName)).should('be.visible');
        cy.xpath(selectors.taskValueTxt.replace('taskName', taskName)).click();

    }
    verifyRequestisCompleted(requestId) {
        cy.visit('/requests/' + requestId);
        var p = 5;
        for (var i = 0; i < p; i++) {
            cy.get('h4').then(el => {
                var text = el.text();
                if (text == 'Completed') {
                    p = 0;
                }
                else {
                    cy.wait(5000);
                    cy.reload();
                }
            })

        }
        cy.xpath(selectors.verifyRequestIsCompleted).should('be.visible');
    }
    manualtaskcomplete() {
        cy.get(selectors.manualtaskcompleteBtn).click();
    }
    verifytaskiscompleted() {
        cy.xpath(selectors.verifyTaskIsCompleted).should('be.visible');
        cy.wait(1000);
    }
    gotocompletedrequest(name) {
        cy.wait(2000);
        cy.xpath(selectors.clickonrequestpage).click();
        cy.xpath(selectors.verifyrequestpage).should('be.visible');
        cy.xpath(selectors.clickoncompleted).click();
        cy.xpath(selectors.verifyCmpltdrequestpage).should('be.visible');
        cy.xpath(selectors.clickonPrcssDrpDwn).click();
        cy.xpath(selectors.clickonPrcssSrchBx).type(name);
        cy.xpath(selectors.clickonPrcssSrchBx).type('{enter}');
        cy.wait(3000);
        cy.xpath(selectors.clickonSearchBtn).click();
        cy.xpath(selectors.verifyPrcssCmpltd).should('be.visible');
        cy.xpath(selectors.openCmpltdPrcss).click();
    }
    clickonfilemanager() {
        cy.xpath(selectors.clickonfilemanager).click();
    }

    /**
     * This method is responsible for start a request in a process with many start events
     * @param processName: name of process to start a request
     * @param nroButton: number of start button
     * @return nothing returns
     */
    openNewRequestByNumberStartButton(processName, nroButton) {
        const processRow = "//span[text()='processName']/parent::div/parent::div[@class='row']";

        cy.get('button[id="navbar-request-button"]').click();
        cy.get(selectors.request_processList).should('be.visible');
        cy.get('input[class="form-control"]').type(processName).should('have.value',processName);

        cy.xpath(processRow.replace('processName',processName), { timeout: 10000 })
            .then(() => {
                this.pressStartBTN(processName, nroButton);
            });
    }

    //Press Start button to start a Request
    pressStartBTN(processName, nroButton) {
        cy.wait(3000);
        const startBtn = "//span[text()='processName']/parent::div/parent::div[@class='row']//a[contains(text(),'Start')]";
        cy.xpath(startBtn.replace('processName',processName)).eq(nroButton).should('be.visible').click();
    }

    //Open the task according to Task Name after that a Request was created.
    openTaskByTaskName(taskName) {
        cy.get(selectors.taskNameLink).eq(0).should('contain', taskName).should('be.visible');
        cy.get(selectors.taskNameLink).eq(0).click();
    }

    verifyTitlePage(title) {
        cy.visit('/requests');
        cy.title().should('eq', title);
    }
    verifySidebarMenuOption(num, option) {
        cy.get('.nav-item.filter-bar.justify-content-between.py-2.sidebar-expansion').click();
        cy.get('.nav-item.filter-bar.justify-content-between').eq(num).should('contain', option);
    }

    /**
     * This method is responsible for start a request according to process with unique start event
     * @param processname: name of process to start a request
     * @return nothing returns
     */
    openNewRequest(processname) {
        cy.get('button[id="navbar-request-button"]').click();
        cy.get(selectors.request_processList).should('be.visible');
        cy.get('input[class="form-control"]').type(processname).should('have.value',processname);

        cy.xpath(selectors.request_searchProcessRow.replace('processName',processname), { timeout: 10000 })
            .then(() => {
                cy.xpath(selectors.request_startButtonRow.replace('processName',processname)).should('be.visible').click();
                cy.title().should('eq', 'Request Detail - ProcessMaker');
            });
        cy.xpath("//a[contains(text(),'Forms')]").should('be.visible');
    }

    openRequestByNameForCompletedProcess(processName) {
        navHelper.navigateToCompletedRequests();
        this.addRequestNameToSelectList(processName);
        cy.xpath(selectors.requestInputOption.replace('processName', processName)).click();
        cy.xpath(selectors.completedTxt).should('be.visible');
    }

    /**
     * This method is responsible wait until a text is visible in a component
     * @param type: type of selector, this could be "selector, xpath"
     * @param selectorXPath: selector or xpath of element like: (//div['id=user'], [data.cy="id2"])
     * @param text: text that the element should to ave
     * @param maxAttempts: # to try , 10 by defauls
     * @param attempts: it is not change
     * @return nothing returns
     */
    waitUntilTextcontainText(type,selectorXPath,text,maxAttempts=10, attempts=0){
        if (attempts > maxAttempts) {
            throw new Error("Timed out waiting for report to be generated");
        }
        if(type === 'selector'){
            cy.get(selectorXPath).should('be.visible').invoke('text')
                .then($val => {
                    if ($val !== text) {  // do your condition check synchronously
                        cy.wait(3000);
                        cy.reload();
                        this.waitUntilTextcontainText(type,selectorXPath,text,maxAttempts, attempts+1);
                    }
                })
        }else{
            cy.xpath(selectorXPath).should('be.visible').invoke('val')
                .then($val => {
                    if ($val !== text) {  // do your condition check synchronously
                        cy.wait(3000);
                        cy.reload();
                        this.waitUntilTextcontainText(type,selectorXPath,maxAttempts, attempts+1);
                    }
                })
        }

    }
    openProcessInTaskPage(name,formTaskName){
        cy.xpath(selectors.searchProcessDrpDwn).click();
        cy.xpath(selectors.searchProcessTxtBx).type(name);
        cy.xpath(selectors.searchProcessTxtBx).type('{enter}');
        cy.wait(2000);
        cy.xpath(selectors.searchTaskNameTxtBx).type(formTaskName);
        cy.wait(2000);
        cy.xpath(selectors.searchTaskNameTxtBx).type('{enter}');
        cy.xpath(selectors.clickonSearchBtn).click();
        cy.xpath(selectors.openTheProcess).should('be.visible').click();
    }

    /**
     * This method is responsible to wait until elemnt is visible
     * @param type: type of selector, this could be "selector, xpath"
     * @param selectorXPath: selector or xpath of element like: (//div['id=user'], [data.cy="id2"])
     * @param maxAttempts: # to try , 10 by default
     * @param attempts: it is not change
     * @return nothing returns
     */
    waitUntilElementIsVisible(type,selectorXPath,maxAttempts=10, attempts=0){
        if (attempts > maxAttempts) {
            throw new Error("Timed out waiting for report to be generated");
        }
        if(type === 'selector'){
            cy.wait(3000);
            cy.xpath('//body')
                .then($body => {
                    if ($body.find(selectorXPath).length <= 0) {
                        cy.reload();
                        this.waitUntilElementIsVisible(type,selectorXPath,maxAttempts, attempts+1);
                    }
                })
        }

    }

    openInPogressProcessInAllRequests(processName){
        navHelper.navigateToAllRequests();
        this.addRequestNameToSelectList(processName);
        cy.xpath(selectors.requestInputOption.replace('processName', processName)).click();
    }

}